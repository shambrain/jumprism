# Optional SAM 2 Worker (Future M2)

No worker code or model weights are included yet. This folder documents the future integration boundary.

The first implementation should be a local, optional Python subprocess that accepts bounded JSON requests and returns a structured response. Unity should invoke it only during authoring. It must never be required to play a saved level.

Before implementing:

1. Read `../../docs/04_AI_AND_IMAGE_PIPELINE.md`.
2. Verify the exact SAM 2 code and checkpoint licence and record pinned versions/checksums.
3. Benchmark CPU inference with representative images on the actual development PC.
4. Test ONNX Runtime DirectML only as a separate experiment; do not assume SAM 2 exports cleanly or accelerates on RX 6700 XT.
5. Add a worker contract, protocol fixtures, timeouts, cancellation and malformed-output tests before Unity integration.

Never commit model weights, private source media, virtual environments, caches or user files to this repository.
