# Technology Stack and Architecture Decision

**Decision status:** recommended, not yet validated by a local Unity build.

## Selected stack

| Layer | Selection | Reason / constraint |
|---|---|---|
| Engine | Unity 6.3 LTS | Video support is central; mature Windows build, C# and asset/tool ecosystem. Verify exact editor requirements and codecs. |
| Language | C# | Main gameplay, editor, persistence, geometry and deterministic validation code. |
| IDE | Visual Studio or VS Code | Use debugger and analyzers; Unity Editor remains the scene/asset/import environment. |
| Agent | OpenCode or equivalent | Repository-aware planning, code edits, command execution and test loops. It does not replace Unity Editor or guarantee engine build availability. |
| AI segmentation | SAM 2.1 in optional local Python worker | Pretrained image/video segmentation; keep out of the gameplay runtime. |
| Image processing | OpenCV | Masks, connected components, contours, resampling and diagnostics. |
| Serialization | Versioned JSON manifest + binary assets | Human-inspectable metadata and portable packages. |
| Distribution | Windows PC / Steam | Target market; Steam Workshop after local content pipeline is validated. |

## Engine comparison

| Requirement | Unity 6.3 LTS | Godot 4.x | GameMaker |
|---|---|---|---|
| 2D platformer | Strong | Strong | Strong |
| Custom in-game editor | Strong | Strong | Possible, more bespoke plumbing |
| MP4/MOV video workflow | Stronger built-in importer/player path; codec support remains platform-specific | Built-in VideoStreamPlayer primarily supports Ogg Theora; other codecs usually need extension or preprocessing | Less attractive for video-first pipeline |
| C# | Primary scripting language | Supported with caveats and version-specific workflow | Not the engine's native scripting language |
| AI/model ecosystem | Wider Unity/.NET interoperability choices | Flexible but more integration work | Most integration must be custom |
| Engine licensing | Proprietary terms; Unity Personal eligibility threshold currently documented at USD 200k revenue/funding | MIT open-source engine | Proprietary commercial licence |
| Current decision | **Selected for evaluation** | Strong fallback | Not selected |

## OS/hardware gate

The developer's current known PC configuration is Windows 10, Ryzen 5 7600X, Radeon RX 6700 XT 12 GB and 32 GB RAM. The exact Windows build is not recorded here.

- Verify `winver` and Windows build before Unity installation. The researched Unity 6.3 requirement is Windows 10 21H1 / build 19043 or newer; confirm against the current system-requirements page.
- Verify Unity Hub and Unity Editor version after installation; do not assume an old editor is compatible.
- CPU inference is the initial fallback for SAM 2.1.
- Do not assume ROCm/HIP support for RX 6700 XT on Windows.
- Test ONNX Runtime DirectML separately; the fact that DirectML exists does not prove a SAM 2 export will run correctly or fast on this exact GPU.

## Runtime boundaries

### Unity client (C#)

Responsibilities:

- Player movement, collisions, camera, enemies and game loop.
- Creator UI, selection, drawing and editing.
- Media import validation and preview.
- Mask display and editable support-surface geometry.
- Deterministic geometry cleanup and candidate extraction where practical.
- Level package read/write and validation.
- Runtime platform tracks using fixed-step physics.

### Local segmentation worker (Python, optional)

Responsibilities:

- Load a pinned SAM 2.1 model/checkpoint.
- Accept image/frame input, prompt points or boxes and request ID.
- Return a mask, model/version metadata, timing and structured errors.
- Support cancellation/timeouts and bounded input size.
- Never execute arbitrary model output as code or write outside its temporary workspace.

Suggested first integration: a managed subprocess with JSON messages over stdin/stdout; send diagnostics/progress to stderr. Avoid opening a network port for the first prototype. A local service can be considered later if lifecycle and security are properly designed.

### Deterministic geometry/physics layer

Responsibilities:

- Validate mask dimensions and binary representation.
- Clean small noise and connected components.
- Extract contours and simplify geometry.
- Propose top-facing support surfaces.
- Validate support length, slope, headroom and collision separation.
- Construct a jump-reachability graph using the same movement parameters as gameplay.

AI proposes visual understanding. Deterministic code determines whether a platform is physically usable.

## Proposed source boundaries

```text
Assets/Jumprism/
  Art/
  Audio/
  Prefabs/
    Player/
    Platforms/
    Hazards/
    Enemies/
  Scenes/
    Boot/
    Menus/
    Creator/
    Gameplay/
  Scripts/
    Core/
    Gameplay/
    Physics/
    Creator/
    Media/
    Segmentation/
    Geometry/
    Validation/
    Persistence/
    Steam/
  Tests/
    EditMode/
    PlayMode/
```

Use assembly definitions when the code boundaries are stable. Keep third-party code isolated from first-party gameplay code.

## Important implementation decisions

- Do not use Unity scene serialization as the public level package format.
- Use stable generated IDs for level objects.
- Store source media separately from masks, approved surfaces and runtime colliders.
- Do not run segmentation or route search continuously in `Update`/`FixedUpdate`.
- Use fixed-step physics and interpolated visuals for moving platforms.
- Use staged/atomic saves; preserve the last valid level on save failure.
- Pin package and model versions after compatibility tests.

## Licensing and distribution checks

Before bundling anything, review its exact licence and the licence of its weights, dependencies, codecs and binary builds. SAM 2's code/checkpoint licensing must be recorded with the exact model version. OpenCV, ONNX Runtime, FFmpeg builds, Unity packages and Steamworks SDK terms each need separate review. FFmpeg licensing depends on build configuration and linked components; do not assume every binary build has identical obligations.
