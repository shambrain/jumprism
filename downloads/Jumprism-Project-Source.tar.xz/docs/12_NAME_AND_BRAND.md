# Name and Brand Decision

## Selected working name: Jumprism

**Pronunciation:** JUMP-riz-um  
**Repository slug:** `jumprism`  
**Tagline:** Turn any scene into a world you can jump through.

## Why this name

- **Jump** communicates the platforming action immediately.
- **Prism** suggests taking a visual scene and transforming it into something new and interactive.
- The combined word is short, memorable and flexible enough to cover both the game and creator tools.
- It does not lock the product to photographs only; video, layered scenes and future media types can fit the same identity.

## Name collision checks performed on 2026-11-12

- Exact web searches for `Jumprism` with game/software/company and Steam terms returned no obvious exact product result in the checked search results.
- GitHub repository search did not return an exact `Jumprism` repository. Similar-looking unrelated repositories may be returned by fuzzy search.
- Nearby candidate names were rejected because of clear collisions: `Leapframe` is used by a film/motion-design business; `Hopscape` is an existing platformer and design studio; `Leaploom` is an existing iOS puzzle game and GitHub repository; `Scenehop` is an existing events-discovery product; `Hopframe` is used by unrelated software/services.

## Important limitation

This is only an initial public-web/GitHub collision check. It does not establish trademark availability, company-name availability, domain ownership, social handle availability or Steam store-name availability. Do not pay for domains, file trademark applications or make irreversible branding commitments until a proper trademark and store availability review is completed.

## Naming convention

- Product/game: **Jumprism**
- Repository: **`jumprism`**
- Internal Unity project: **Jumprism**
- Level package format identifier: **`jumprism-level`** (proposal)
- Proposed package extension: **`.jumprism`** (proposal; reserve only after implementation decision)
- Main docs heading: **Jumprism — Product and Engineering Blueprint**

## Brand direction (initial)

A playful but polished visual identity: vivid portal-like colour refractions, crisp geometric shapes, bold readable typography and scenic imagery. Avoid a generic AI-tech aesthetic; the product is about movement, imagination and turning familiar scenery into playable spaces.
