# Level Package Format — Proposal v1

## Goals

- Portable between editor and runtime.
- Independent of Unity scene serialization.
- Versioned and validated.
- Human-inspectable metadata.
- Assets stored in a predictable package directory.
- Safe to import from untrusted sources.

## Package layout

```text
MyLevel.jumprism/
  level.json
  media/
    background.png
    background.mp4
  masks/
    object-<stable-id>.png
  geometry/
    surfaces.json
  tracks/
    moving-platform-<stable-id>.json
  preview.png
```

The extension is a proposal and can be changed before public release. Internally the package can be a ZIP archive with a manifest at its root.

## Proposed manifest

```json
{
  "format": "jumprism-level",
  "schemaVersion": 1,
  "levelId": "01JUMPRISMEXAMPLE0000000000",
  "metadata": {
    "title": "Forest Canopy",
    "description": "A sample image-based platforming level.",
    "author": "Creator",
    "createdUtc": "2026-11-12T00:00:00Z",
    "modifiedUtc": "2026-11-12T00:00:00Z",
    "tags": ["forest", "image-platforming"]
  },
  "world": {
    "pixelsPerUnit": 100.0,
    "gravity": 28.0,
    "cameraBounds": { "minX": 0.0, "minY": 0.0, "maxX": 19.2, "maxY": 10.8 }
  },
  "media": [
    {
      "assetId": "background-01",
      "path": "media/background.png",
      "kind": "image",
      "width": 1920,
      "height": 1080,
      "sha256": "REPLACE_WITH_LOWERCASE_64_CHARACTER_SHA256"
    }
  ],
  "objects": [
    {
      "id": "surface-01",
      "kind": "oneWayPlatform",
      "enabled": true,
      "mediaAssetId": "background-01",
      "geometry": {
        "coordinateSpace": "world",
        "points": [
          { "x": 2.0, "y": 3.0 },
          { "x": 4.0, "y": 3.2 }
        ]
      },
      "properties": {
        "friction": 0.4,
        "minimumSupportWidth": 0.8
      }
    },
    {
      "id": "player-start",
      "kind": "playerSpawn",
      "enabled": true,
      "transform": { "x": 1.0, "y": 2.0, "rotationDegrees": 0.0 }
    },
    {
      "id": "goal-01",
      "kind": "goal",
      "enabled": true,
      "transform": { "x": 17.5, "y": 8.0, "rotationDegrees": 0.0 }
    }
  ],
  "provenance": {
    "segmentationModel": null,
    "segmentationVersion": null,
    "geometryAlgorithmVersion": "surface-extractor-0.1"
  }
}
```

This is an illustrative proposal, not an implemented schema. The real schema must be versioned and validated by code before levels are considered compatible.

## Required validation

- `format` must match exactly.
- `schemaVersion` must be supported; never silently guess a migration.
- Stable IDs must be unique within their collection.
- All numeric values must be finite; reject NaN and infinity.
- Dimensions, counts, array lengths, strings and total decompressed package size must have explicit limits.
- Every asset path must be relative, normalized and remain inside the package root. Reject traversal, rooted paths and unexpected links.
- Verify hashes before using media or mask assets.
- Verify referenced media/object IDs exist.
- Require one valid player spawn and one goal for the normal playable mode.
- Geometry must contain sufficient valid points, remain within configured world bounds and have no invalid/self-intersecting polygons where prohibited.
- Platform tracks must be ordered by time, use valid transforms, match video duration and declare invalid intervals.
- Reject unsupported object kinds and properties rather than ignoring them silently.

## Save/load behaviour

- Write to a temporary package path.
- Flush and verify the manifest/assets.
- Atomically replace the prior file/package where supported.
- Keep a recoverable backup until the new save succeeds.
- On load, validate manifest first, then assets, then construct runtime/editor objects.
- On any error, preserve the current editor session and present an actionable message.

## Future migrations

Add explicit migration code when `schemaVersion` increments. Keep old level fixtures in automated tests. Never rewrite a source level just because a newer editor opened it; require a deliberate save/migration step.
