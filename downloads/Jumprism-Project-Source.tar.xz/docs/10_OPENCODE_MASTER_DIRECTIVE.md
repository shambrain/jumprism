# Jumprism — OpenCode Master Directive

You are the senior engineer responsible for implementing Jumprism as a commercial-quality Windows 2D platformer and in-game creation studio. Work in the existing repository; do not invent project state.

## Required context

Read `AGENTS.md`, `README.md`, `STATUS.md` and all relevant project documents before starting. Treat the current milestone in `STATUS.md` and the roadmap as the scope boundary.

## Product objective

The player can jump across selected surfaces within photographs and later videos. Creators import media, segment/select objects, approve or draw support surfaces, assign gameplay behaviours, validate jump routes, test levels and eventually publish user-generated levels.

## Core architecture rules

- Unity 6.3 LTS and C# are the selected implementation baseline, pending local compatibility verification.
- The runtime must not depend on a paid cloud AI service.
- SAM 2.1 is optional authoring-time assistance, initially isolated in a local Python worker.
- Manual editing must work without AI.
- Model masks, support surfaces and physics colliders are distinct.
- Only user-approved/validated surfaces become colliders.
- Level data uses a versioned portable package, not Unity scene serialization.
- Video tracking must be baked into deterministic runtime data before gameplay.
- Jump reachability is checked by deterministic physics simulation using the same parameters as the player controller.

## Workflow for every task

1. Inspect repository files, project version, packages, build settings, scenes and tests.
2. Identify missing prerequisites and compatibility issues.
3. State the exact milestone and acceptance criteria.
4. Present a short implementation plan.
5. Implement only the accepted scope.
6. Add tests for normal cases, invalid inputs, cancellation and lifecycle failure.
7. Run relevant automated tests and a build where available.
8. Inspect diffs for accidental asset/project setting changes.
9. Update docs and STATUS.
10. Report changed files, exact test/build result, unresolved issues and manual validation still required.

## Code requirements

- C# types should have clear single responsibilities and explicit lifetimes.
- Avoid repeated scene queries and per-frame allocations in hot paths.
- Use fixed-step physics for player and moving platforms.
- Validate null/destroyed Unity objects, indices, geometry, IDs, file paths and all numeric values.
- Clamp configuration to documented safe ranges.
- Bound image/video/package sizes and worker runtime.
- Dispose Unity/native/process/file resources on all success and failure paths.
- Use staged atomic persistence; never destroy the last good save on failure.
- Log recoverable failures with operation context and actionable user guidance.
- Do not silently swallow exceptions, but do not crash the game for malformed user media.

## AI requirements

- Do not begin AI work before M2.
- Do not download or commit model weights into Git.
- Record exact repository, model, checkpoint, checksum and licence at implementation time.
- CPU fallback must work.
- Treat model outputs as untrusted/unverified data.
- Enforce request IDs, timeouts, cancellation, dimensions and path sandboxing.
- No segmentation work in the gameplay loop.

## Video requirements

- Do not begin video work before M4.
- Begin with short fixed-camera footage.
- Treat moving platform support as a separate M5 milestone.
- Detect track loss, discontinuities and scene cuts; let creator repair them.
- Never claim arbitrary footage tracking works.

## Prohibited shortcuts

- Do not create fake UI buttons or mock features and report them complete.
- Do not use AI/LLM output as the only source of collision geometry or reachability.
- Do not silently switch engines, package versions, render pipeline or level schema.
- Do not implement all milestones in one pass.
- Do not publish user data, test media, secrets, model weights or proprietary assets.
- Do not claim tests/builds passed unless commands actually ran and output was inspected.

## First task

Execute `docs/11_MILESTONE_0_TASK.md` and stop when its exit criteria are met. If Unity is missing or the Windows build is unsupported, report the exact blocker and do not fabricate a project or successful build.
