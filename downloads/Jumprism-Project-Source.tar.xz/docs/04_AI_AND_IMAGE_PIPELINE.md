# AI-Assisted Image Pipeline

## Guiding rule

**AI segments the scene; deterministic algorithms derive gameplay geometry; the creator approves the result.**

SAM 2 does not understand platformer rules. It can help isolate an object but it cannot reliably declare a branch, cloud or rooftop safe to stand on.

## Proposed components

- **SAM 2.1:** prompted image segmentation and video-object tracking at authoring time.
- **OpenCV:** mask normalization, connected components, morphology, contours and debug output.
- **C# geometry code:** support-surface generation, simplification, constraints and runtime-ready collider data.
- **C# jump solver:** actual reachability tests using configured player physics.

## Image authoring pipeline

1. **Validate import:** allowlisted file types; size, dimensions, pixel count and decode validation; reject corrupted files safely.
2. **Normalize coordinates:** preserve source pixel dimensions, orientation and scale mapping into Unity world units.
3. **Prompt:** accept a positive point, negative points, bounding box or manual mask.
4. **Segment:** run SAM 2.1 in the optional local worker.
5. **Normalize output:** validate that mask dimensions match the source; clamp and threshold values; reject empty or malformed masks.
6. **Clean mask:** remove tiny connected components; optionally close small gaps; preserve holes when relevant; provide before/after previews.
7. **Trace contours:** extract external and relevant internal contours; simplify with a bounded error tolerance.
8. **Propose support surfaces:** inspect upper boundary runs and identify candidate ledges/branches.
9. **Apply constraints:** minimum support width, acceptable slope, continuity, clearance/headroom, and configurable confidence threshold.
10. **Preview:** display candidate surfaces over the image and show collision geometry distinctly from the source mask.
11. **Approve/edit:** user can accept, reject, move endpoints, add points or switch to manual drawing.
12. **Persist:** store model/version/prompt metadata as provenance; store approved geometry independently from the raw model output.

## Support-surface extraction

An object mask is a set of occupied pixels, not a walkable polygon. Extract the top-facing boundary of the mask and group nearby segments into candidate support surfaces.

Candidate checks should include:

- Surface length and minimum supported player-foot width.
- Slope and local curvature limits.
- Gaps and discontinuities.
- Vertical clearance above the surface for the player's collider.
- Whether the surface is on the visible/top-facing side of the object.
- Whether collision would intersect the player's spawn, another collider or a hazardous region.
- Whether an actual simulated jump can reach it.

Use simple one-way edge/platform colliders for ordinary ledges. Do not turn all mask pixels into colliders or build a collider per pixel.

## Model and hardware strategy

- Prototype CPU inference first. The local RX 6700 XT on Windows is not a safe assumption for ROCm/HIP acceleration.
- Evaluate ONNX Runtime DirectML only after model export compatibility has been verified and benchmarked on the exact GPU/driver/Windows build.
- Benchmark small and large model variants on representative images and clips; record latency, peak RAM/VRAM and mask quality.
- Keep model weights out of Git. Provide an explicit setup/download step and exact checksum/version.
- Never make a Steam player download a model just to play a published level.
- AI failure must fall back to manual tools with a useful message.

## Worker contract (proposal)

Request fields:

- `requestId` — unique ID.
- `operation` — image segmentation operation.
- `inputPath` — controlled temporary source path.
- `positivePoints` and `negativePoints` — source-image coordinates.
- `box` — optional normalized/pixel-space bounding box.
- `modelId` — explicit pinned model variant.

Response fields:

- `requestId` — must match the request.
- `status` — `ok`, `cancelled` or `error`.
- `maskPath` — generated mask inside the controlled job directory.
- `sourceWidth`, `sourceHeight` — exact dimensions.
- `modelId`, `modelVersion` — provenance.
- `durationMs` — measured processing time.
- `errorCode`, `message` — structured failure when not `ok`.

Validate every response path and size. The worker must not return an arbitrary filesystem path that the Unity client blindly opens.

## Limits and failure modes

- Empty mask: do not create geometry.
- Mask/source dimensions mismatch: reject the result.
- Oversized image: request downscale or reject with an actionable reason.
- Model unavailable/out of memory: keep manual editor usable.
- Timeout/cancel: terminate or cancel the worker safely and clean temporary resources.
- Fragmented mask: show quality warning and let creator refine.
- Uncertain top edge: present candidates, never auto-approve.
- Multiple overlapping surfaces: allow separate support objects with explicit priority/identity.

## Later AI enhancements

Only after the baseline is useful:

- Text-to-object selection as a convenience layer.
- Semantic suggestions such as "likely branch" or "possible rooftop" using a separate classifier/VLM.
- Assisted placement of hazards/enemies, constrained by the deterministic route solver.
- Automatic parallax/layer suggestions where depth can be reasonably inferred.

A language model may suggest, explain or rank. It must not be the authoritative source of collision coordinates or physics validity.
