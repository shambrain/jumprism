# Quality, Reliability and Test Plan

## Test layers

### Pure/EditMode tests

- Coordinate conversion between source pixels, canvas and world space.
- Mask dimension and binary-value validation.
- Connected-component filtering and contour simplification.
- Candidate support-surface extraction.
- Slope, width and clearance constraints.
- Level JSON schema, unique IDs, paths and SHA-256 verification.
- Save/load round-trip and migration fixtures.
- Jump-trajectory solver against known analytical/simple cases.

### PlayMode tests

- Player run/jump/fall/grounded transitions.
- Coyote time/jump buffer if included in final control design.
- Landing on horizontal/sloped/narrow platforms.
- One-way collision from above and pass-through from below.
- Hazards, checkpoint, respawn and goal completion.
- Pause/restart and scene reload.
- Moving platform land/ride/jump-off after M5.

### Manual acceptance tests

- First-time creator can import a photo and draw a platform.
- Pan/zoom does not desynchronize cursor and geometry.
- Undo/redo works across mixed creator operations.
- Clear debug distinction between visual source, selected mask and physics collider.
- Save and reopen a level on a clean Windows installation.
- Test multiple aspect ratios, very tall/wide images and high-DPI displays.

## Robustness and failure injection

- Missing asset, unreadable file, corrupt image/video, invalid JSON.
- Empty/null geometry, one-point line, duplicated points and self-intersecting polygons.
- NaN/infinite/out-of-range coordinates.
- Very large dimensions, compressed package bombs and excessive asset counts.
- Invalid relative path and path traversal attempts.
- Hash mismatch or missing referenced file.
- Segmentation worker not installed, fails to start, times out, crashes, returns wrong request ID or malformed mask.
- User cancels import/inference mid-operation.
- Unity object destroyed during an async editor operation.
- Disk full or access denied during save.
- Video codec unsupported, frame count excessive, scene cut and tracking loss.

## Performance guardrails

- No AI inference in gameplay `Update`/`FixedUpdate`.
- Avoid per-frame allocations in player/physics hot paths.
- Avoid repeated scene-wide searches in hot loops.
- Limit contour points and collider counts after geometry simplification.
- Mark geometry dirty and recompute only the edited object/candidate when possible.
- Keep explicit caps for source file bytes, decoded pixel count, video duration, sampled frames, mask bytes and package size.
- Benchmark cold/warm inference, editor responsiveness, package save/load and gameplay frame pacing.

## Definition of done for each task

- Acceptance criteria written before implementation.
- Failure cases validated.
- Relevant EditMode/PlayMode tests added and run.
- No unhandled warnings/errors from changed code.
- No placeholder controls represented as working features.
- Documentation and `STATUS.md` updated.
- Actual command/test/build output reported accurately.
