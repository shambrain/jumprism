# GitHub Repository Setup and Upload

The prepared repository slug is **`jumprism`** under the authenticated GitHub account **`shambrain`**.

## Create the empty repository

The connected GitHub actions available in the current session can write files and commits to an existing repository, but they do not expose the GitHub `Create Repository` operation. Therefore, repository creation itself must be done once in GitHub's UI.

1. Open https://github.com/new while signed in as `shambrain`.
2. Repository name: `jumprism`.
3. Description: `A photo- and video-powered 2D platformer and in-game creator that turns real scenes into playable levels.`
4. Visibility: **Private recommended** while the commercial concept and implementation are in development. Change it later deliberately if open-sourcing is intended.
5. Add a README file so GitHub creates the initial `main` branch.
6. Do not select a licence yet. The source-code licensing strategy has not been decided.
7. Create the repository.

Expected URL: `https://github.com/shambrain/jumprism`

## Complete the upload

Once the repository exists, provide its URL in the conversation. The connected GitHub write actions can then add this prepared file tree to the existing repository and verify the committed paths. Do not create a differently named repository; keep `jumprism` consistent across the project.

## Local upload alternative

If you prefer to push the archive yourself, extract it so the folder is named `jumprism`, open PowerShell in the folder that contains `jumprism`, and run:

```powershell
$source = (Resolve-Path .\jumprism).Path
$destination = Join-Path (Get-Location).Path "jumprism-github"
git clone https://github.com/shambrain/jumprism.git $destination
robocopy $source $destination /E /XD .git
Set-Location $destination
git add -A
git commit -m "docs: add Jumprism project blueprint"
git push origin main
```

`robocopy` may return exit codes 1–7 when files were copied or differences were found; those are not necessarily failures. Review `git status` and the staged diff before committing. This alternative requires Git and an authenticated GitHub credential manager; never put a personal access token into a command, script or repository file.
