# OpenCode Task — Milestone 0: Manual Photo-Platforming Vertical Slice

## Objective

Prove the core Jumprism experience before AI or video exists: a player can jump across manually drawn platforms placed over an imported or bundled photograph, and a creator can save/reopen the geometry.

## Before coding

1. Read `AGENTS.md`, `STATUS.md`, `docs/00_PROJECT_CHARTER.md`, `docs/03_TECH_STACK_AND_ARCHITECTURE.md`, `docs/06_LEVEL_FORMAT_V1.md`, `docs/07_DEVELOPMENT_ROADMAP.md` and `docs/08_QUALITY_AND_TEST_PLAN.md`.
2. Inspect the repository and local machine. Verify the exact Windows 10 build (`winver`), Unity Hub availability, Unity 6.3 LTS editor installation, Windows Build Support and IDE integration.
3. If the Unity version or OS prerequisite is not met, stop and report the actual state with an actionable setup plan. Do not create pretend Unity project files.
4. Inspect package versions, render pipeline, input settings and physics settings before editing.

## Implementation scope

- Create a clean Unity 6.3 LTS 2D project only when prerequisites pass.
- Establish folders/assembly boundaries for Core, Gameplay, Physics, Creator, Media, Geometry, Validation, Persistence and Tests.
- Add one static photograph background. Use an appropriately licensed bundled placeholder or a local-only test fixture; never commit personal photos without explicit permission.
- Implement a small player controller with idle/run, jump, falling/grounded state and restart.
- Implement a manual one-way platform line tool with editable endpoints/control points.
- Add selection/deletion and minimal undo/redo for platform geometry.
- Draw a collision/debug overlay visually distinct from the photograph.
- Implement save/load of a versioned JSON level document and referenced test media/geometry.
- Keep visual background separate from support surfaces and runtime collision bodies.

## Required tests

- Player moves, jumps and lands on a horizontal surface.
- Player falls when there is no surface.
- Player passes upward through a one-way platform from below.
- Player lands on it from above.
- Invalid/empty/duplicate/non-finite platform points are rejected.
- Coordinate mapping remains correct at multiple zoom levels and resolutions.
- Save/load round-trip preserves geometry and IDs.
- Missing/invalid media returns a recoverable editor error.
- Cancelled save/import does not corrupt the previous valid level.

## Explicitly out of scope

Do not implement SAM 2, ONNX, DirectML, video import/tracking, moving platforms, auto-route, enemy AI, Steamworks, Workshop, online services, cloud accounts or generative AI.

## Exit report

Report:

- Unity/editor version and verified Windows build.
- New/changed files and project settings.
- Exact test command and pass/fail/skipped totals.
- Windows development-build result and output location.
- Manual playtest instructions and known limitations.
- Whether all M0 exit criteria are met.

Stop after Milestone 0. Do not begin M1 automatically.
