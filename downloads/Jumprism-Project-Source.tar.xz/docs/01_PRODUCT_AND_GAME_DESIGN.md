# Product and Game Design

## Core loop

1. Choose a source scene (image in the first release; video in later milestones).
2. Mark interesting objects or draw areas manually.
3. Create or approve support surfaces.
4. Assign gameplay behaviour.
5. Add a player start, goal and optional hazards/enemies.
6. Validate the route and test-play it.
7. Refine, save and share.

## Creator modes

### Manual mode — foundational

Must always work, including with AI disabled or offline:

- Platform-line drawing with editable endpoints and intermediate points.
- Polygon/solid collision drawing where needed.
- Mask brush and eraser for later segmentation refinement.
- Select, move, duplicate, delete and resize objects.
- Undo/redo for geometry and object-property operations.
- Pan/zoom, snap options and collision-debug overlays.
- Start, goal, checkpoint, hazard and enemy spawn markers.

### AI-assisted mode — differentiator

- Click or box-select an object.
- Receive a proposed object mask.
- Add positive/negative correction clicks.
- Inspect one or more candidate support surfaces extracted from the mask.
- Accept, edit or reject each candidate.
- Assign behaviour only after approval.

### Video tracking mode — advanced

- Import a short clip.
- Scrub to a frame and select one object.
- Track the object across sampled frames.
- Review tracking overlays and confidence.
- Correct lost or drifted frames manually.
- Convert the chosen support surface into a baked moving-platform track.

## Gameplay object catalogue

| Object | Runtime behaviour | Editor responsibility |
|---|---|---|
| Background media | Render only | Position, scale, opacity, layer/parallax |
| One-way platform | Supports player from above | Editable support line/edge, thickness and material |
| Solid platform | Blocks from all intended sides | Simplified polygon/edge collider |
| Moving platform | Carries player along a baked path | Track, speed, loop/ping-pong and validation |
| Hazard | Damages or resets player | Shape, activation and effect configuration |
| Player spawn | Initial spawn location | Exactly one active start per playable level |
| Checkpoint | Updates respawn location | Stable ID and activation rules |
| Enemy spawn | Creates or activates enemy | Enemy type and validated reachable surface |
| Trigger | Fires a gameplay event | Bounds, event type and target |
| Goal/exit | Completes level | Exactly one required goal unless a future mode says otherwise |

## Level design principles

- A level should communicate which surfaces are safe and which are decorative.
- Keep the first campaign levels curated and teach one mechanic at a time.
- Do not add randomness to required story routes unless explicitly designed as a game mechanic.
- Auto-route must suggest, not silently decide, the final layout.
- Enemy placement must not make a required jump unfair or impossible.
- Provide a clear way to see collision geometry during authoring and testing.

## Auto-Route feature

Auto-Route is a proposed high-value creator feature:

1. Creator approves candidate surfaces.
2. Creator places start and goal.
3. A deterministic solver tests candidate jumps using actual player movement parameters.
4. The editor displays a path through reachable surfaces.
5. Unreachable surfaces and impossible gaps are highlighted.
6. Creator may ask for suggestions such as adding a checkpoint or moving a surface, but retains final control.

The solver's output must match runtime physics within tested tolerances. A path must never be labelled playable based only on geometric proximity.

## Campaign concept

A small initial campaign (roughly 8–12 polished levels as a planning target, not a fixed promise) should demonstrate several media styles:

- Forest: branches, trunks and rocks.
- Sky: clouds and floating objects.
- City: rooftops, ledges and signs.
- Road: vehicles as static obstacles first; moving platforms much later.
- Shore/ocean: rocks, boats and floating objects.
- Experimental: mixed imagery, layered backgrounds and creator-made routes.

The campaign should teach movement, one-way platforms, hazards, moving platforms and editor possibilities in a deliberate difficulty curve.
