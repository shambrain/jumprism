# Research Sources and Verification Notes

**Research date:** 2026-11-12

This source index records the official product/technical pages and developer discussions used for the initial project decision. Availability and documentation can change; verify the exact version before implementation or release.

## Competitors and adjacent products

- Picture Grid Engine: https://factorydigital.itch.io/picturegridengine
- Viewfinder (Steam): https://store.steampowered.com/app/1382070/Viewfinder/
- Levelhead (Steam): https://store.steampowered.com/app/792710/Levelhead_Platformer_Maker/
- Cursedland (Steam): https://store.steampowered.com/app/3447170/
- Camera Obscura (Steam): https://store.steampowered.com/app/341500/

## Engine and distribution

- Unity 6.3 LTS release: https://unity.com/blog/unity-6-3-lts-is-now-available
- Unity 6.3 system requirements: https://docs.unity.com/en-us/engine/6000.3/manual/get-started/install-and-upgrade/getting-started-installing-unity/system-requirements
- Unity video file compatibility: https://docs.unity.com/en-us/engine/6000.3/manual/video/sources/file-compatibility
- Unity Personal eligibility: https://unity.com/products/unity-personal
- Godot licence: https://godotengine.org/license/
- Godot 4.7.2 stable release archive: https://godotengine.org/download/archive/
- Godot video playback formats: https://docs.godotengine.org/en/latest/tutorials/animation/playing_videos.html
- Godot 2D collision shapes: https://docs.godotengine.org/en/latest/tutorials/physics/collision_shapes_2d.html
- Godot editor plugins: https://docs.godotengine.org/en/stable/tutorials/plugins/editor/making_plugins.html
- Steam Workshop documentation: https://partner.steamgames.com/doc/features/workshop

## AI, image/video processing and hardware

- Meta SAM 2 project: https://ai.meta.com/research/sam2/
- SAM 2 official repository/checkpoint licence: https://github.com/facebookresearch/sam2
- ONNX Runtime DirectML: https://onnxruntime.ai/docs/execution-providers/DirectML-ExecutionProvider.html
- ONNX Runtime Windows guidance: https://onnxruntime.ai/docs/get-started/with-windows.html
- AMD ROCm Radeon/Windows system requirements: https://rocm.docs.amd.com/projects/radeon-ryzen/en/docs-7.1.1/docs/shared/hipsdk/reference/system-requirements.html
- FFmpeg legal/licensing information: https://www.ffmpeg.org/legal.html

## Real developer/community discussions

- Godot Reddit — TrenchBroom-style in-editor level editor: https://www.reddit.com/r/godot/comments/1utnnhh/i_built_a_trenchbroomstyle_level_editor_directly/
- Godot Reddit — JSON player level editor: https://www.reddit.com/r/godot/comments/1vct0ow/i_made_a_level_editor_for_my_players_json_files/
- Reddit — Godot vs Unity for solo indie development: https://www.reddit.com/r/IndieGameDevs/comments/1w3ckt6/unity_or_godot_for_a_solo_indie_developer/
- Godot Forum — standalone level editor discussion: https://forum.godotengine.org/t/before-i-go-down-a-rabbit-hole/128703
- Godot Forum — custom editor/main-screen plugin: https://forum.godotengine.org/t/making-a-new-tab-like-the-2d-or-3d-tab-using-a-custom-plugin/95612

## Verification notes

- Competitor descriptions are used only to identify overlap; they are not evidence of sales or audience size.
- Reddit/forum posts are anecdotes and engineering examples, not controlled benchmarks.
- Unity video codec support is platform/codec dependent; verify target Windows build and test media formats.
- Unity Personal terms, package versions, AI model terms and Steamworks policies should be rechecked before commercial distribution.
- The AMD GPU inference plan remains unbenchmarked on the user's exact machine. CPU is the initial safe fallback; DirectML is an experiment, not a performance guarantee.
- No market-size, sales, conversion or pricing forecast is asserted.
