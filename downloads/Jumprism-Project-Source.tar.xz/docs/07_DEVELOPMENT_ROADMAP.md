# Development Roadmap and Exit Criteria

The roadmap is deliberately sequential. Each milestone must pass its exit criteria before the next major system is added.

## M0 — Manual photo-platforming vertical slice

**Goal:** prove jumping on manually created geometry over a photograph is fun and reliable.

Scope:
- Clean Unity 6.3 LTS 2D project and source-folder/assembly plan.
- One background photograph.
- Placeholder player with run, jump, fall, grounded state and restart.
- Manual one-way platform drawing with editable points.
- Collision debug overlay.
- Basic level save/load using schema v1 or a clearly marked prototype subset.

Exit criteria:
- Playable outside the editor after a Windows development build.
- Landing, one-way collision and falling are stable.
- Save/load round-trip preserves player start and platform geometry.
- Automated tests exist and pass for core movement/geometry/persistence.
- Manual tester can draw a platform and test it without developer assistance.

Not in scope: SAM 2, video, auto-route, Steam, network, enemies unless needed for the simplest playable loop.

## M1 — Useful image creator

Scope:
- JPG/PNG import with limits and error handling.
- Pan/zoom canvas, selection, line/polygon, brush/eraser, undo/redo.
- Start, goal, checkpoint, hazard and enemy spawn markers.
- Reusable object inspector and collision overlay.
- Level package with referenced media and hashes.

Exit criteria:
- Create/edit/delete tools behave consistently.
- Undo/redo restores both geometry and properties.
- Reopen/save does not shift coordinates or corrupt referenced assets.
- Oversized/corrupt image import fails gracefully.

## M2 — AI image segmentation

Scope:
- Optional SAM 2.1 local Python worker.
- Prompt with clicks/boxes and mask-return contract.
- Mask overlay and manual correction.
- Candidate top-surface extraction and approval UI.

Exit criteria:
- AI disabled/unavailable still leaves full manual workflow usable.
- Worker has timeout, cancel, bounded memory/file handling and structured errors.
- Candidate collider geometry is deterministic for the same input/version.
- Creator can reject AI output and recover without losing edits.
- Benchmarks recorded on the developer's actual PC.

## M3 — Jump validation and assisted route generation

Scope:
- Configurable player movement parameters.
- Candidate jump simulation.
- Directed reachability graph.
- Start-to-goal validation and route display.
- Warnings for impossible gaps, inadequate headroom or unapproved geometry.

Exit criteria:
- Solver agrees with PlayMode results within documented tolerances across test fixtures.
- No route marked valid if runtime player cannot traverse it.
- Route suggestion remains editable and optional.

## M4 — Video as a visual background

Scope:
- Supported short video import and playback.
- Scrub, pause, loop and timing controls.
- Static/manual platforms over video.

Exit criteria:
- Codec/size/duration errors are detected and explained.
- Pause, seek, loop and level restart behave predictably.
- Gameplay does not require video frame processing in the physics loop.

## M5 — Tracked moving platforms

Scope:
- Single selected object on fixed-camera footage.
- Offline tracking/segmentation.
- Keyframe preview and correction.
- Baked transform/surface track.
- Kinematic platform implementation.

Exit criteria:
- Player can land, ride and jump off consistently.
- Track drift/loss is detectable and repairable.
- No scene-cut or loop-boundary teleport bug in the defined supported footage class.
- Track is playable without running the AI model.

## M6 — Curated content and Steam release foundation

Scope:
- Campaign levels and onboarding.
- Local level package import/export.
- Settings, input remapping, accessibility basics and build pipeline.
- Crash/error telemetry only if privacy-respecting and explicitly approved.
- Steamworks/Workshop integration after format stability.

Exit criteria:
- A standalone Windows build works on clean test machines.
- Content validation and import abuse tests pass.
- Demo/campaign contains a polished showcase of the core mechanic.
- Steam store messaging accurately describes implemented features.

## M7 — Workshop and community features

Scope:
- Upload/download via Steam Workshop.
- Level preview, tags, ratings/favourites and reporting flow as supported by Steamworks/product design.
- Content validation, size limits and graceful handling of removed/unavailable subscriptions.

Exit criteria:
- Workshop items are validated before load.
- Unsupported versions are rejected/migrated explicitly.
- Download failures do not corrupt local data.
- Moderation and reporting responsibilities are defined.
