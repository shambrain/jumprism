# Project Charter

## Working product name

**Jumprism**

**Tagline:** Turn any scene into a world you can jump through.

## One-sentence pitch

Jumprism is a 2D platformer and in-game creation studio where players turn their own photographs and video footage into playable jumping worlds by selecting, drawing and validating platform surfaces.

## The original player fantasy

A child looks at a moving scene and imagines jumping from one thing to another: a branch, a rooftop, a passing vehicle, a cloud, a sign or a rock. Jumprism turns that daydream into a game-creation mechanic. The scenery is not just decoration; selected parts become places the player can stand, jump from and interact with.

## Product shape

Jumprism combines two tightly connected experiences:

1. **A polished platform game** that demonstrates the mechanic through curated campaign levels.
2. **An accessible in-game creator** that transforms user-selected media into editable, testable levels.

The creator is the differentiator, but the shipped game must be enjoyable without requiring the community to supply all the content.

## Product pillars

### 1. Make real scenes playable

Support imported images first and video later. The user chooses what becomes interactive.

### 2. AI assists; the creator decides

AI proposes masks and candidate surfaces. Users can correct, reject or draw geometry manually. No opaque auto-generation is allowed to silently alter gameplay.

### 3. Physics over visual guesses

An object mask is not a platform. The system extracts candidate support surfaces, simplifies collision geometry and verifies actual jump reachability.

### 4. Fun before technical spectacle

The basic movement, camera, platform readability and landing feel must be enjoyable before model integration.

### 5. Portable user-created content

Levels are versioned packages containing a manifest and referenced media/geometry assets. They must be validated before loading or sharing.

## Target audience hypotheses

- Players who enjoy creative platformers and user-generated levels.
- Casual creators who want to make a level from a photo without learning a conventional game editor.
- Streamers and community creators who enjoy turning unusual images or short clips into challenges.
- Platformer fans interested in unusual environments and physics interactions.

These are hypotheses. Validate them through prototype playtests and a small Steam-facing demo before making sales forecasts.

## Core use cases

1. Import a photograph and make a few branches into one-way platforms.
2. Import a city image and turn approved rooftops into a jump route.
3. Select a cloud/object and ask AI for a mask; manually correct it.
4. Place start, goal, checkpoints, hazards and enemy spawn markers.
5. Press Test and play immediately.
6. Save/export a portable level and share it locally.
7. Later, import a short video and track one rigid moving object as a platform.

## Non-goals for the first prototype

- A general-purpose 2D/3D game engine.
- Automatic full-scene understanding or perfect one-click level generation.
- Photorealistic dynamic collision for every object in a video.
- Real-time AI inference during gameplay.
- Online multiplayer or cloud level hosting.
- Steam Workshop before the local level package format is reliable.
- Training a proprietary segmentation model from scratch.

## Success criteria for the first vertical slice

- A creator can import a still image, draw and edit support surfaces, place a start and goal, and test the level.
- The player can run, jump, land and fall with consistent, readable physics.
- One-way surfaces behave correctly from above and below.
- The level can be saved, closed, loaded and played with geometry preserved.
- The test suite covers core movement, collision and persistence failure paths.
- A first-time tester can understand the editor without instructions from the developer.

## Product positioning

Do not position Jumprism as the first product that turns images or video into explorable worlds. Existing precedents make that broad claim unsafe. Position it around **turning selected image/video surfaces into real platforming geometry and playable jump routes**.
