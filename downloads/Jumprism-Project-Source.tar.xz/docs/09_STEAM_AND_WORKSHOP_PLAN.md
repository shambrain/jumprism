# Steam Release and Workshop Plan

## Commercial product shape

Jumprism should ship as a real platform game with a creator studio built into the same application. The curated campaign demonstrates the mechanic and gives buyers meaningful content even before the Workshop has a large catalogue.

## Recommended order

1. Local creator and playable campaign.
2. Local save/load and portable export/import.
3. Public demo/playtest and player feedback.
4. Steamworks basics appropriate to release (achievements/cloud saves only when useful and tested).
5. Steam Workshop only after the level package schema and validation pipeline have stabilised.
6. Community discovery and moderation after enough creator activity exists.

## Workshop principles

- Validate every downloaded package before extraction or load.
- Enforce package-size, asset-count and image/video limits.
- Reject path traversal, malformed JSON, unsupported schema versions and bad hashes.
- Do not execute scripts or arbitrary code contained in a level.
- Do not require AI model weights or model execution to play Workshop levels.
- Handle removed, private, unavailable or updated items gracefully.
- Keep a local last-known-good copy where Steamworks policy and user expectations permit.
- Provide clear error messages and a report/abuse mechanism.

## Store-page positioning (draft)

**Short pitch:** Turn your own pictures into platforming worlds. Draw platforms, let optional AI help find objects, build impossible-looking routes, and challenge friends with levels made from scenes only you could have imagined.

Only advertise video-based moving platforms after M5 passes and is included in the build being sold. Do not advertise one-click level generation, universal video support or online features before they exist.

## Pricing / business model

Do not select a price from speculation. Validate the demo, campaign scope, editor value, competing products and player willingness to pay. A paid base game with a free demo is a reasonable hypothesis to test; avoid deciding trial-transfer style restrictions or premium features before user research.

## Release readiness

- Stable Windows build on clean systems.
- Controller and keyboard/mouse support tested.
- Clear first-use creator tutorial.
- Campaign levels polished and fully playable offline.
- User-level validation and import limits.
- Crash recovery and save backups.
- Accurate store screenshots/trailer showing only shipped features.
- Steamworks permissions, policies, SDK version and Workshop flow checked against current Valve documentation.
