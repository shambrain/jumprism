# Competitive Research and Positioning

**Research snapshot:** 2026-11-12. This is a desk-research snapshot, not a complete market census, legal clearance or proof of demand.

## Executive assessment

The broad concept of using a photograph or video as an explorable game environment is not entirely new. The most direct overlap found in this research is Picture Grid Engine. Other products validate adjacent parts of the concept: photo manipulation inside a game, platformer level editors, image import and user-generated content.

The proposed differentiation is the particular workflow:

1. Import photography/video as visual media.
2. Select/segment objects.
3. Extract editable top-facing support surfaces.
4. Generate simplified physics colliders.
5. Verify that the player can actually jump between them.
6. Later, bake stable moving platforms from video tracking.

Do not claim that Jumprism is the first game to turn images or video into explorable worlds.

## Products examined

| Product | Relevant overlap | Difference / positioning note |
|---|---|---|
| [Picture Grid Engine](https://factorydigital.itch.io/picturegridengine) | Closest conceptual predecessor found: image/video-based explorable stages. | Its reviewed description focuses on walking/running exploration, grid interaction, image restoration and events. The research did not find documentation of top-surface extraction, platformer physics or jump-route validation. Re-check the current product before public comparisons. |
| [Viewfinder](https://store.steampowered.com/app/1382070/Viewfinder/) | Photos, paintings and sketches become part of the game world. | First-person puzzle game rather than a user-facing photo/video-to-platformer editor. |
| [Levelhead](https://store.steampowered.com/app/792710/Levelhead_Platformer_Maker/) | Platformer creation, enemies, hazards, sharing and a creator community. | Uses conventional authored game objects, not surfaces extracted from a creator's own footage. |
| [Cursedland](https://store.steampowered.com/app/3447170/) | Platformer editor and custom content; import features overlap with creator flexibility. | The reviewed information does not describe automatic collision-surface extraction from video/photo media. |
| [Camera Obscura](https://store.steampowered.com/app/341500/) | Visual manipulation and custom level-editor concepts. | Uses a specific afterimage mechanic; not a general media segmentation and platform-generation pipeline. |

## Community evidence examined

- [Godot Reddit: TrenchBroom-style editor inside the Godot viewport](https://www.reddit.com/r/godot/comments/1utnnhh/i_built_a_trenchbroomstyle_level_editor_directly/) — evidence that substantial custom editor workflows can be built inside a game engine.
- [Godot Reddit: player-facing level editor with JSON levels converted into scenes](https://www.reddit.com/r/godot/comments/1vct0ow/i_made_a_level_editor_for_my_players_json_files/) — relevant to portable, data-driven user levels.
- [Godot Reddit: Godot vs Unity discussion for a solo developer](https://www.reddit.com/r/IndieGameDevs/comments/1w3ckt6/unity_or_godot_for_a_solo_indie_developer/) — anecdotal community opinions, not a benchmark.
- [Godot Forum: standalone level editor discussion](https://forum.godotengine.org/t/before-i-go-down-a-rabbit-hole/128703) — relevant to integrating a creator into the shipped game.

Community posts are anecdotal and should not be treated as controlled comparisons or proof of demand.

## Market viability: what is and is not established

**What is supported:** adjacent games demonstrate player interest in creative platformers, photo manipulation and user-generated levels. Tools and engines provide building blocks for the technical pipeline.

**What is not established:** willingness to pay for this exact combination, likely Steam sales, price, audience size, conversion rate, retention, or the cost of supporting arbitrary user media.

## Validation plan before committing to a full game

1. Build the manual photo-platforming prototype.
2. Show a short capture to 10–20 target players/creators; observe whether they understand the mechanic without explanation.
3. Give testers a blank photograph and ask them to create a playable route. Measure time-to-first-playable-level and completion rate.
4. Compare manual-only and AI-assisted workflows. Measure whether AI meaningfully saves time without introducing frustrating corrections.
5. Test a small Steam demo/festival-style build only after the prototype is stable.
6. Gather wishlist intent, qualitative feedback and repeated-use evidence before selecting price or release model.

## Public messaging guardrails

Safe positioning: “A platformer and in-game creator that turns your own images — and later video — into jumping worlds.”

Avoid: “The first game that turns pictures into worlds,” “one-click perfect AI level generation,” “any video becomes a working platformer,” or unverified sales/market-size claims.
