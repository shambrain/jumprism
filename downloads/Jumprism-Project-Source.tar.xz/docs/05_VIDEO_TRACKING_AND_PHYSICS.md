# Video, Moving Platforms and Physics

## Why video is a separate milestone

A moving video background is straightforward compared with a platform that is physically safe to land on and ride. A segmented object may deform, rotate, disappear behind another object, leave the frame, or be affected by camera movement. A visually plausible track is not automatically a stable physics surface.

## Staged video support

### Stage A — video as decoration

- Import a short supported video.
- Preview, scrub and loop it as a background layer.
- Allow manually drawn static platforms over the video.
- Do not infer moving colliders.

### Stage B — offline object tracking

- Begin with fixed-camera footage, no hard cuts, low camera shake and one prominent rigid/near-rigid object.
- Prompt the object on a frame.
- Propagate/track the mask through sampled frames.
- Extract the support surface on each usable frame.
- Show overlays and confidence; creator repairs bad frames.

### Stage C — baked moving platform

- Store a small set of timestamped transforms and support-surface points in object-local coordinates.
- Smooth noisy movement and let creator correct keyframes.
- Bake a path that can be evaluated independently of the AI model.
- Drive a kinematic Rigidbody2D at the physics tick.
- Interpolate rendering between physics samples without allowing render timing to control collisions.

### Stage D — difficult footage

Only after Stage C is stable, consider camera motion compensation, partial occlusion, deformation, multiple tracked objects and scene changes. Do not promise arbitrary footage support.

## Moving-platform representation

A track should contain:

- Stable platform/object ID.
- Source video asset ID and content hash.
- Timebase and duration.
- Ordered keyframes with timestamp, position and optional rotation/scale.
- Local-space support-surface geometry.
- Tracking confidence and manual-correction marker per keyframe.
- Loop mode: once, loop or ping-pong.
- Track validity status and invalid intervals.

## Runtime rules

- Evaluate platform pose at fixed physics time.
- Prefer kinematic motion with explicit delta/velocity handling.
- Use a stable local collider for rigid translation; avoid rebuilding the polygon each frame.
- Carry a grounded player consistently and allow jumping off without stale parent/velocity state.
- Detect invalid track intervals; freeze/disable the surface or make it non-colliding in a documented safe way.
- Handle loop boundaries without teleporting the collider through the player.
- Do not silently interpolate across scene cuts.

## Mandatory physics tests

1. Player lands on a stationary platform.
2. Player passes through a one-way platform from below.
3. Player can jump from the platform without residual platform velocity.
4. Player rides a moving platform without jitter or unintended slipping.
5. Platform carries the player through both directions of a ping-pong path.
6. Loop boundary never teleports through the player.
7. Tracking loss invalidates the track safely.
8. Player is not trapped by a platform that suddenly changes shape.
9. Frame-rate variation does not change the physics result materially.
10. Video pause, seek, playback-speed changes and level pause have explicit behaviour.

## Media constraints

Initial clips should be short and bounded. Validate codec, dimensions, duration, frame rate and file size before allocating large textures or sampling frames. Do not assume that an MP4 extension guarantees a supported codec profile on every target PC.
