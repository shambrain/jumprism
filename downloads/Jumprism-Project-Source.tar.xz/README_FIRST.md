# Before the first implementation session

1. Read `README.md` and `AGENTS.md`.
2. Check `STATUS.md`; the project is still at documentation/pre-production stage.
3. Read the engine decision and verify your exact Windows build before creating the Unity project.
4. Follow `docs/11_MILESTONE_0_TASK.md` exactly.
5. Do not ask OpenCode to implement SAM 2, video tracking or Workshop yet.

Repository setup/upload steps: [`docs/GITHUB_UPLOAD.md`](docs/GITHUB_UPLOAD.md).
