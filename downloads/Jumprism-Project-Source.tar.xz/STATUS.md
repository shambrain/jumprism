# Jumprism — Project Status

**Last updated:** 2026-11-12  
**Stage:** pre-production / implementation not started  
**Repository:** `shambrain/jumprism` (proposed; repository has not yet been created)  
**Product name:** Jumprism (preliminary name search; no trademark clearance)

## Confirmed decisions

- Product concept: 2D platformer plus in-game image/video-based level creator.
- Main engine recommendation: Unity 6.3 LTS, pending OS/editor compatibility verification.
- Main programming language: C#.
- Coding workflow: OpenCode edits source and runs available checks; Unity Editor/CLI performs engine-specific import, test and build tasks.
- AI: optional offline SAM 2.1 segmentation worker; manual tools and deterministic geometry remain authoritative.
- First deliverable: manual photo-background platforming vertical slice, no AI or video tracking.
- Target platform: Windows PC; Steam release is the commercial target.
- Repository name proposal: `jumprism`.

## Not yet done

- No GitHub repository has been created or populated.
- No Unity project has been created.
- No C# gameplay code exists yet.
- No SAM 2 model has been installed or benchmarked.
- No prototype has been playtested.
- No Steam page, app ID, Workshop integration or commercial validation exists.

## Gates before implementation

1. Verify the exact Windows 10 build and Unity 6.3 editor compatibility.
2. Install/verify Unity Hub, Unity 6.3 LTS editor, Windows Build Support and Visual Studio/VS Code integration.
3. Create a clean Unity 2D project and commit the initial project settings.
4. Complete Milestone 0 acceptance criteria in `docs/07_DEVELOPMENT_ROADMAP.md`.

## Open questions

- Final art direction and player character identity.
- Final commercial price and whether any free/trial mode is appropriate.
- Public or private source repository; private is recommended during commercial development.
- Final licensing for original source code and any bundled third-party components.
- Maximum supported source image/video dimensions and durations after profiling.
