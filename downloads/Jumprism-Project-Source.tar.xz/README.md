# Jumprism

**Turn any scene into a world you can jump through.**

Jumprism is a proposed Windows/Steam 2D platformer and in-game creation studio. Its defining mechanic is the ability to turn photographs and, later, video footage into playable platforming environments. Creators import media, select or draw useful surfaces, review AI-generated object masks, assign gameplay behaviours, test the resulting level, and eventually share creations through Steam Workshop.

> **Project stage:** pre-production / prototype planning. This repository contains the product definition, research, technical decisions, level-format proposal, quality plan and OpenCode instructions. It does not yet contain a playable Unity project or implemented gameplay code.

## The core idea

A player can jump onto scenery that would normally be decorative: branches, rooftops, rocks, clouds, signs, vehicles and other objects. A creator can build that world without manually modelling every platform.

Jumprism deliberately separates four concepts:

1. **Visual media** — the photograph or video shown to the player.
2. **Object mask** — which pixels belong to a selected object.
3. **Support surface** — the editable portion where a character may stand.
4. **Physics collider** — the simplified shape used by the runtime physics system.

The AI may propose a mask or candidate surface. Deterministic geometry and physics code validate the result. The creator always has manual drawing and correction tools; AI is optional.

## Product pillars

- **Play first:** jumping and landing on an imported photograph must feel good before advanced AI is built.
- **Creator control:** manual tools remain first-class; AI never silently decides collision behaviour.
- **Reliable physics:** visible masks are not automatically treated as solid collision bodies.
- **Offline-first authoring:** local image segmentation should not require a paid cloud API.
- **Shareable levels:** a versioned, portable level package is the public interchange format, not a Unity scene.
- **Honest automation:** video tracking, auto-route and enemy suggestions must be previewed and validated before acceptance.

## Recommended stack

| Area | Recommendation |
|---|---|
| Engine | Unity 6.3 LTS (verify installed Windows build and supported package versions before project creation) |
| Main language | C# |
| IDE | Visual Studio or VS Code; Unity Editor remains required for project and scene workflows |
| Coding agent | OpenCode or a compatible repository-aware coding agent |
| AI segmentation prototype | Meta SAM 2.1 through an optional local Python worker |
| Image/mask processing | OpenCV plus deterministic C# geometry where practical |
| Windows inference experiment | CPU first; evaluate ONNX Runtime DirectML only after measuring model compatibility and performance on the RX 6700 XT |
| Level format | Versioned JSON manifest plus referenced media/mask/track assets |
| Distribution | Windows PC / Steam; Workshop after local import/export and validation are stable |

Unity is the current recommendation because video is part of the product direction. Godot remains the main alternative if the project shifts toward static-image-first functionality or open-source engine licensing becomes the deciding factor. See [technology decision](docs/03_TECH_STACK_AND_ARCHITECTURE.md).

## First milestone

Build a small Unity 2D vertical slice:

- one imported photograph as a background;
- one simple player with run, jump, fall, landing and restart;
- a manual line/polygon tool for creating one-way platforms over the photograph;
- editable platform geometry and visible collision overlays;
- save/load of a versioned level document;
- automated tests for jump/landing, one-way collision and save/load.

**Do not start with SAM 2, video tracking, Steam Workshop, networking or generative AI.** The first milestone must prove the basic play experience and creator interaction.

## Repository guide

- [`docs/00_PROJECT_CHARTER.md`](docs/00_PROJECT_CHARTER.md) — product purpose, scope and non-goals.
- [`docs/01_PRODUCT_AND_GAME_DESIGN.md`](docs/01_PRODUCT_AND_GAME_DESIGN.md) — player loop, creator modes and core gameplay.
- [`docs/02_COMPETITIVE_RESEARCH.md`](docs/02_COMPETITIVE_RESEARCH.md) — existing games/tools and positioning.
- [`docs/03_TECH_STACK_AND_ARCHITECTURE.md`](docs/03_TECH_STACK_AND_ARCHITECTURE.md) — engine, languages, runtime boundaries and architecture.
- [`docs/04_AI_AND_IMAGE_PIPELINE.md`](docs/04_AI_AND_IMAGE_PIPELINE.md) — SAM 2, mask cleanup and platform-surface extraction.
- [`docs/05_VIDEO_TRACKING_AND_PHYSICS.md`](docs/05_VIDEO_TRACKING_AND_PHYSICS.md) — staged video support and moving-platform constraints.
- [`docs/06_LEVEL_FORMAT_V1.md`](docs/06_LEVEL_FORMAT_V1.md) — proposed portable level package and JSON example.
- [`docs/07_DEVELOPMENT_ROADMAP.md`](docs/07_DEVELOPMENT_ROADMAP.md) — milestones and exit criteria.
- [`docs/08_QUALITY_AND_TEST_PLAN.md`](docs/08_QUALITY_AND_TEST_PLAN.md) — edge cases, automated checks and performance gates.
- [`docs/09_STEAM_AND_WORKSHOP_PLAN.md`](docs/09_STEAM_AND_WORKSHOP_PLAN.md) — release and user-generated-content strategy.
- [`docs/10_OPENCODE_MASTER_DIRECTIVE.md`](docs/10_OPENCODE_MASTER_DIRECTIVE.md) — standing instructions for the coding agent.
- [`docs/11_MILESTONE_0_TASK.md`](docs/11_MILESTONE_0_TASK.md) — first implementation assignment.
- [`docs/12_NAME_AND_BRAND.md`](docs/12_NAME_AND_BRAND.md) — name rationale and naming checks.
- [`docs/RESEARCH/RESEARCH_AND_IMPLEMENTATION_BLUEPRINT.md`](docs/RESEARCH/RESEARCH_AND_IMPLEMENTATION_BLUEPRINT.md) — consolidated initial research blueprint.
- [`docs/RESEARCH/SOURCES.md`](docs/RESEARCH/SOURCES.md) — source index and verification notes.
- [`UnityProject/README.md`](UnityProject/README.md) — instructions for creating the actual Unity project after the pre-production gate.
- [`tools/sam2-worker/README.md`](tools/sam2-worker/README.md) — proposed optional local segmentation worker.

## OpenCode starting point

1. Read `AGENTS.md`.
2. Read the project charter, technology decision, roadmap, quality plan and Milestone 0 task.
3. Verify the installed Windows build, Unity Hub/editor version, required modules and package availability.
4. Create a clean Unity 2D project only after the compatibility check passes.
5. Implement Milestone 0 only. Do not jump ahead to AI/video/Workshop.

## Status

See [`STATUS.md`](STATUS.md) for the confirmed project state. Research is a starting point, not a guarantee of product-market fit, trademark availability or runtime compatibility. Verify current terms, licences, model packaging rules and Unity support before distribution.
