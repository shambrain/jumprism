# Unity Project Placeholder

This directory is intentionally not a Unity project yet.

Create the actual Unity 6.3 LTS project here only after verifying the Windows build and Unity installation prerequisites described in `../docs/03_TECH_STACK_AND_ARCHITECTURE.md` and completing the setup step in `../docs/11_MILESTONE_0_TASK.md`.

Do not add placeholder `ProjectSettings`, `Packages/manifest.json`, scenes or scripts that could be mistaken for a working Unity project. Once the project exists, add the generated Unity files here and update `.gitignore`, `STATUS.md` and the project documentation.
